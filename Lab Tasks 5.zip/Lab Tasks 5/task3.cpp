#include<iostream>
#include<string>
using namespace std;

class stringType 
{
    string s1;
    string s2;
public:
    stringType() 
    {
        s1 = "\0";
        s2 = "\0";
    }
    void setValues(string str1, string str2) 
    {
        s1 = str1;
        s2 = str2;
        return;
    }
    void DisplayValues() 
    {
        cout << "First string: " << s1 ;
        cout << "\nSecond String: " << s2 ;
        return;
    }
    int compr(string s1, string s2) 
    {
        if (s1 == s2)
            return 0;
        else if (s1 > s2)
            return 1;
        else if (s1 < s2)
            return -1;
    }
    void copy(string source, string dest) 
    {
        dest = source;
        cout << "The copied string is:" << dest;
        return;
    }
    int maxLength() 
    {
        int l1 = 0;
        int l2 = 0;

        for (int i = 0; s1[i] != '\0'; i++) 
        {
            l1++;
        }
        for (int i = 0; s2[i] != '\0'; i++) 
        {
            l2++;
        }
        if (l1 >= l2)
            return l1;
        else
            return l2;
    }
    string concatenate(string s1, string s2) 
    {
        return s1 + s2;
    }
    int searchWord(string word) 
    {
        string temp = s1;
        int i = 0;

        while (temp[i] != '\0') 
        {
            int j = 0;
            char token[1000];
            while (temp[i] != '\0') 
            {
                token[j] = temp[i];

                if (temp[i] == ' ') 
                {
                    i++;
                    j++;
                    break;
                }
                i++;
                j++;
            }
            token[j] = '\0';
            cout << token <<endl;
            if (token == word)
                return 1;
        }
        return 0;
    }

    int searchChar(char ch) 
    {
        int i = 0;
        while (s1[i] != '\0') 
        {
            if (s1[i] == ch)
                return 1;
            else
                i++;
        }
        return 0;
    }

    ~stringType() {}

};


int main() 
{
    int option = 0;
    stringType s;
    string w1, w2, word;
    while(1) 
    {
        cout << "\n1. Enter values of string.";
        cout << "\n2. Print values";
        cout << "\n3. Max Length";
        cout << "\n4. Compare Strings.";
        cout << "\n5. Copy String";
        cout << "\n6. Concatenate String";
        cout << "\n7. Search word in string.";
        cout << "\n8.  Search character in String";
        cout << "\n9. Exit";
        cout << "\nSelect an option: ";
        cin >> option;

        switch (option) 
        {
        case 1:
            cout << "Enter first string: ";
            cin.ignore(1000, '\n');
            getline(cin, w1);

            cout << "Enter second string: ";

            getline(cin, w2);

            s.setValues(w1, w2);
            break;
        case 2:
            s.DisplayValues();
            break;
        case 3:
            cout << "Max Length:" << s.maxLength();
            break;
        case 4:
            if (s.compr(w1, w2) == 0) {
                cout << "The strings are identical" ;
            }
            else if (s.compr(w1, w2) == 1) {
                cout << "The w1 string is larger!" ;
            }
            else if (s.compr(w1, w2) == -1) {
                cout << "The w1 string is smaller!" ;
            }
            break;
        case 5:
            s.copy(w1, w2);
            break;
        case 6:
            cout << "The concatenated string is:" << s.concatenate(w1, w2);
            break;
        case 7:
            cout << "Enter the word you want to search :";
            cin.ignore();
            getline(cin,word);
            cout << s.searchWord(word);
            if (s.searchWord(word) == 1)
                cout << "Word found";
            else
                cout << "The word is not in the string!";

            break;
        case 8:
            char ch;
            cout << "Enter the character you want to search:";
            cin >> ch;
            if (s.searchChar(ch) == 1)
                cout << "Character Found!";
            else
                cout << "The character is not in the string!";
            break;
        case 9:
            break;
        default:
            cout << "Invalid option!";
            break;

        if(option == 9)
            break;
        }



    };


    return 0;
}