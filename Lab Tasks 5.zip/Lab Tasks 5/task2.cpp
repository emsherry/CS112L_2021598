#include<iostream>
using namespace std;

class parity {
    public:
    int size;
    int* arr;
    void del();
    void put(int num);
    void display();
    int test();

    parity(){
        size=0;
        arr=new int[size];
    }
    ~parity(){}
    
};

void parity::put(int num) 
    {
        size += 1;
        int* temp = new int[size];
        for (int i = 0; i < size; i++) {
            temp[i] = arr[i];
        }
        delete[] arr;
        arr = temp;
        arr[size - 1] = num;
        return;
    }
    void parity::del()
    {
        if (size == 0) {
            cout << "No elements!\n" l;
            return;
        }
        size -= 1;
        int* temp = new int[size];
        for (int i = 0; i < size; i++) {
            temp[i] = arr[i];
        }
        delete[] arr;
        arr = temp;
        return;
    }
    void parity::display()
    {
        if (size == 0) {
            cout << "\nNo Elements" ;
            return;
        }
        cout << "Input Elements are: " << endl;
        for (int i = 0; i < size; i++) {
            cout << arr[i] << "  ";
        }
        cout << endl << endl;
        return;
    }
    int parity::test() 
    {
        if ((size % 2) == 0)
            return 1;
        else if ((size % 2) == 1)
            return 0;
    }

int main() 
{
    int option = 0, num = 0;
    parity p;

    
    while (1) 
     {
        cout << "\n1. Add Element";
        cout << "\n2. Print All. ";
        cout << "\n3. Delete last Element";
        cout << "\n4. Chech for  Even or Odd.";
        cout << "\n5. Exit";
        cout << "\nSelect an option: ";
        cin >> option;
        
        switch (option) {
        case 1:
            cout << "Enter element: ";
            cin >> num;
            p.put(num);
            break;
        case 2:
            p.display();
            break;
        case 3:
            p.del();
            break;
        case 4:
            if (p.test() == 1) {
                cout << "\nEven!";
            }
            else if (p.test() == 0) {
                cout << "\nOdd!";
            }
            break;
        case 5:
            break;
        default:
            cout << "Invalid option!";
            break;

        if(option == 5)
            break;
        }

    }


    return 0;
}