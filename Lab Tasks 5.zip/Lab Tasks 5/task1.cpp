#include <iostream>
using namespace std;


class Heater {
	int temp;
public:
	Heater()
	{
		temp = 15;
	}
	void cooler()
	{
		temp = temp - 5;
		cout << "\nTemperature Cooled!";
	}
	void warmer()
	{
		temp = temp + 5;
		cout << "\nTemperature Warmed!";
	}
	void print()
	{
		cout << "\nTemperature : " << temp << endl;
	}
	~Heater(){};

};
int main()
{
	Heater h;
	int n =0;
	cout << "\n1. Cooler.";
	cout << "\n2. Warmer.";
	cout << "\n3. Temperature.";
	cout << "\n4. Exit";
	
	

	while (1)
	{
		cout << "\nEnter Option: ";
		cin >> n;
		if (n < 1 || n>4)
			cout << "Enter between 1 and 4 only!";
		else
		{
			switch (n)
			{
			case 1:
				h.cooler();
				break;
			case 2:
				h.warmer();
				break;
			case 3:
				h.print();
				break;
			case 4:
				break;
			}
			if (n == 4)
				break;
		}
	}
}
